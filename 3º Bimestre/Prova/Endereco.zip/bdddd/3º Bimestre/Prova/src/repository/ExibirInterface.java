package repository;

public interface ExibirInterface {

}