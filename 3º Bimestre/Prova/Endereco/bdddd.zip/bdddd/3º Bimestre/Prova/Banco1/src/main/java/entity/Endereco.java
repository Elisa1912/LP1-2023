package entity;

import jakarta.persistence.*;

@Entity(name = "Enderecos")
@Table(name = "Enderecos")

public class Endereco {
    @Id
    @GeneratedValue(
            strategy = GenerationType.IDENTITY
    )

    @Column(
            name = "coluna"
    )

    private int id;
    @Column
    private String Cidade;
    @Column
    private String Rua;

    public Endereco(String cidade, String rua) {
        Cidade = cidade;
        Rua = rua;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getCidade() {
        return Cidade;
    }

    public void setCidade(String cidade) {
        Cidade = cidade;
    }

    public String getRua() {
        return Rua;
    }

    public void setRua(String rua) {
        Rua = rua;
    }

    @Override
    public String toString() {
        return "Endereco{" +
                "id=" + id +
                ", Cidade='" + Cidade + '\'' +
                ", Rua='" + Rua + '\'' +
                '}';
    }
}
