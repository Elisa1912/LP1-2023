import model.ItemPedido;

public class Main {
    public static void main(String[] args) {
        ItemPedido itempedido = new ItemPedido();
    }
}
